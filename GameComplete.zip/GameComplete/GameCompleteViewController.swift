//
//  GameCompleteViewController.swift
//  ShurikenShooter
//
//  Created by il17aag on 12/01/2020.
//  Copyright © 2020 il17aag. All rights reserved.
//

import UIKit
import AVFoundation

class GameCompleteViewController: UIViewController
{
    @IBOutlet weak var backImage: UIImageView!
    @IBAction func gotoMenu(_ sender: Any)
    {
        let main = UIStoryboard(name: "Main", bundle: nil)
        let menu = main.instantiateViewController(identifier: "mainMenuVC")
        self.present(menu, animated: true, completion: nil)
        musicEffect.stop()
    }

    var imageArray = [UIImage(named: "end0.gif")!,
                      UIImage(named: "end1.gif")!,
                      UIImage(named: "end2.gif")!,
                      UIImage(named: "end3.gif")!,
                      UIImage(named: "end4.gif")!,
                      UIImage(named: "end5.gif")!,
                      UIImage(named: "end6.gif")!,
                      UIImage(named: "end7.gif")!,
                      UIImage(named: "end8.gif")!,
                      UIImage(named: "end9.gif")!,
                      UIImage(named: "end10.gif")!,
                      UIImage(named: "end11.gif")!,
                      UIImage(named: "end12.gif")!,
                      UIImage(named: "end13.gif")!]
    
    let A = UIScreen.main.bounds.width
    let B = UIScreen.main.bounds.height
    
    var musicEffect: AVAudioPlayer = AVAudioPlayer()
    override func viewDidLoad()
    {
        super.viewDidLoad()
        playBGMusic()
        //Background Animation
        createBackgroundImage()
        self.view.bringSubviewToFront(menuBtn)
        }
    
    func createBackgroundImage()
    {
        let backImages = UIImageView(image: nil)
        backImages.image = UIImage.animatedImage(with: imageArray, duration: 2.5)
        backImages.frame = CGRect(x: self.A*0.0, y: self.B*0.0, width: self.A, height: self.B)
        self.view.addSubview(backImages)
    }
    
    func playBGMusic()
    {
        let musicFile = Bundle.main.path(forResource: "GameCompleteSound", ofType: ".mp3")
        do{
            try musicEffect = AVAudioPlayer(contentsOf: URL (fileURLWithPath: musicFile!))
            
        }
        catch{
            print(error)
        }
        musicEffect.play()
    }
    @IBOutlet weak var menuBtn: UIButton!
    
}
