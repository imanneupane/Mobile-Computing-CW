//
//  GameOverViewController.swift
//  ShurikenShooter
//
//  Created by il17aag on 12/01/2020.
//  Copyright © 2020 il17aag. All rights reserved.
//

import UIKit
import AVFoundation

class GameOverViewController: UIViewController {

    @IBOutlet weak var backImage: UIImageView!
    @IBAction func playAgain(_ sender: Any)
    {
        let main = UIStoryboard(name: "Main", bundle: nil)
        let replay = main.instantiateViewController(identifier: "firstStageVC")
        self.present(replay, animated: true, completion: nil)
        musicEffect.stop()
    }

    var imageArray = [UIImage(named: "frame0.gif")!,
                      UIImage(named: "frame1.gif")!,
                      UIImage(named: "frame2.gif")!,
                      UIImage(named: "frame3.gif")!,
                      UIImage(named: "frame4.gif")!,
                      UIImage(named: "frame5.gif")!,
                      UIImage(named: "frame6.gif")!,
                      UIImage(named: "frame7.gif")!,
                      UIImage(named: "frame8.gif")!,
                      UIImage(named: "frame9.gif")!,
                      UIImage(named: "frame10.gif")!,
                      UIImage(named: "frame11.gif")!,
                      UIImage(named: "frame12.gif")!,
                      UIImage(named: "frame13.gif")!]
    
    let A = UIScreen.main.bounds.width
    let B = UIScreen.main.bounds.height
    
    var musicEffect: AVAudioPlayer = AVAudioPlayer()
    override func viewDidLoad()
    {
        super.viewDidLoad()
        playBGMusic()
        //Background Animation
        createBackgroundImage()
        self.view.bringSubviewToFront(playAgainBtn)
        self.view.bringSubviewToFront(gameOverImg)
    }
    
    func playBGMusic()
    {
        let musicFile = Bundle.main.path(forResource: "GameOverSound", ofType: ".mp3")
        do{
            try musicEffect = AVAudioPlayer(contentsOf: URL (fileURLWithPath: musicFile!))
            
        }
        catch{
            print(error)
        }
        musicEffect.play()
    }
    
    func createBackgroundImage()
    {
        let backImages = UIImageView(image: nil)
        backImages.image = UIImage.animatedImage(with: imageArray, duration: 2.5)
        backImages.frame = CGRect(x: self.A*0.0, y: self.B*0.0, width: self.A, height: self.B)
        self.view.addSubview(backImages)
    }
    
    @IBOutlet weak var gameOverImg: UIImageView!
    @IBOutlet weak var playAgainBtn: UIButton!
}
