//
//  NextLoadViewController.swift
//  ShurikenShooter
//
//  Created by il17aag on 12/01/2020.
//  Copyright © 2020 il17aag. All rights reserved.
//

import UIKit
import AVFoundation

class NextLoadViewController: UIViewController {


    var imageArray = [UIImage(named:"load1.gif")!,
                           UIImage(named:"load2.gif")!,
                           UIImage(named:"load3.gif")!,
                           UIImage(named:"load4.gif")!,
                           UIImage(named:"load5.gif")!,
                           UIImage(named:"load6.gif")!,
                           UIImage(named:"load7.gif")!,
                           UIImage(named:"load8.gif")!,
                           UIImage(named:"load9.gif")!,
                           UIImage(named:"load10.gif")!,
                           UIImage(named:"load11.gif")!,
                           UIImage(named:"load12.gif")!,
                           UIImage(named:"load13.gif")!,
                           UIImage(named:"load14.gif")!,
                           UIImage(named:"load15.gif")!,
                           UIImage(named:"load16.gif")!,
                           UIImage(named:"load17.gif")!,
                           UIImage(named:"load18.gif")!,
                           UIImage(named:"load19.gif")!,
                           UIImage(named:"load20.gif")!,
                           UIImage(named:"load21.gif")!,
                           UIImage(named:"load22.gif")!,
                           UIImage(named:"load23.gif")!,
                           UIImage(named:"load24.gif")!,
                           UIImage(named:"load25.gif")!,
                           UIImage(named:"load26.gif")!,
                           UIImage(named:"load27.gif")!,
                           UIImage(named:"load28.gif")!,
                           UIImage(named:"load29.gif")!,
                           UIImage(named:"load30.gif")!,
                           UIImage(named:"load31.gif")!]
    
    let A = UIScreen.main.bounds.width
    let B = UIScreen.main.bounds.height
    
    @IBOutlet weak var loadBG: UIImageView!
    
    var musicEffect: AVAudioPlayer = AVAudioPlayer()
    
    func createBackgroundImage()
    {
        let backImages = UIImageView(image: nil)
        backImages.image = UIImage.animatedImage(with: imageArray, duration: 2.5)
        backImages.frame = CGRect(x: self.A*0.0, y: self.B*0.0, width: self.A, height: self.B)
        self.view.addSubview(backImages)
    }
    
    //Goes to Next Stage as the button is clicked or touched
    @IBAction func goNext(_ sender: Any) {
        let main = UIStoryboard(name: "Main", bundle: nil)
        let nextStage = main.instantiateViewController(identifier: "secondStageVC")
        self.present(nextStage, animated: true, completion: nil)
        musicEffect.stop()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        playBGMusic()
        //Background Animation
        createBackgroundImage()
        self.view.bringSubviewToFront(stageImg)
        self.view.bringSubviewToFront(nextBtn)
    }
    
    func playBGMusic()
    {
        let musicFile = Bundle.main.path(forResource: "NextLoadSound", ofType: ".mp3")
        do{
            try musicEffect = AVAudioPlayer(contentsOf: URL (fileURLWithPath: musicFile!))
            
        }
        catch{
            print(error)
        }
        musicEffect.play()
    }
    
    
    @IBOutlet weak var stageImg: UIImageView!
    @IBOutlet weak var nextBtn: UIButton!
    
}
