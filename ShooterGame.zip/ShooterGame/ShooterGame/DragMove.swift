//
//  DragMove.swift
//  ShooterGame
//
//  Created by il17aag on 09/01/2020.
//  Copyright © 2020 il17aag. All rights reserved.
//

import UIKit

class DragMove: UIImageView {

    let imageNames = ["load1.gif", "load2.gif","load3.gif", "load4.gif","load5.gif", "load6.gif","load7.gif", "load8.gif","load9.gif", "load10.gif","load11.gif", "load12.gif","load13.gif", "load14.gif","load15.gif", "load16.gif","load17.gif", "load18.gif","load19.gif", "load20.gif","load21.gif", "load22.gif","load23.gif", "load24.gif","load25.gif", "load26.gif","load27.gif", "load28.gif","load29.gif", "load30.gif","load31.gif"]
    var images = [UIImage]()
    for i in 0..<imageNames.count{
        images.append(UIImage(named: imageNames[i])!)
    }
    loadBG.animationImages = images
    loadBG.animationDuration = 2.0
    loadBG.animationRepeatCount = 1
    loadBG.startAnimating()
    
}
