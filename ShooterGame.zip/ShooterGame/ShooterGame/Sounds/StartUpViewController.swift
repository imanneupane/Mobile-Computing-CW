//
//  StartUpViewController.swift
//  ShooterGame
//
//  Created by il17aag on 11/01/2020.
//  Copyright © 2020 il17aag. All rights reserved.
//

import UIKit
import AVFoundation

class StartUpViewController: UIViewController {

    var musicEffect: AVAudioPlayer = AVAudioPlayer()
    @IBOutlet weak var btnImage: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        let musicFile = Bundle.main.path(forResource: "MainMenuMusic", ofType: ".mp3")
        do{
            try musicEffect = AVAudioPlayer(contentsOf: URL (fileURLWithPath: musicFile!))
            
        }
        catch{
            print(error)
        }
        musicEffect.play()
    }
    
    @IBAction func musicButton(_ sender: Any) {
        
        if btnImage.currentBackgroundImage == UIImage(named: "musicON"){
            btnImage.setBackgroundImage(UIImage(named:"musicOFF"), for: .normal)
            musicEffect.stop()
        }
        else{
            btnImage.setBackgroundImage(UIImage(named:"musicON"), for: .normal)
            musicEffect.play()
        }
    }
}
