//
//  Stage2ViewController.swift
//  ShooterGame
//
//  Created by il17aag on 11/01/2020.
//  Copyright © 2020 il17aag. All rights reserved.
//

import UIKit

class Stage2ViewController: UIViewController, subViewDelegate {

    @IBOutlet weak var timelimit: UILabel!
    @IBOutlet weak var points: UILabel!
    @IBOutlet weak var targetSling: SlingShooter!
    @IBOutlet weak var background2Image: UIImageView!
    
    var dynamicA: UIDynamicAnimator!
    var dynamicB: UIDynamicItemBehavior!
    var collusionB: UICollisionBehavior!
    var ninjaCollusion: UICollisionBehavior!
    var shurikenImageArray: [UIImageView] = []
    var villanViewArray: [UIImageView] = []
    
    var score = 0
    var countdown = 20
    var timer = Timer()
    
    let A = UIScreen.main.bounds.width
    let B = UIScreen.main.bounds.height
    
    var sideX: CGFloat!
    var sideY: CGFloat!
    
    let villanImageArray = [UIImage(named: "villan1.png")!,
        UIImage(named:"villan2.png")!,
        UIImage(named:"villan3.png")!,
        UIImage(named:"villan4.png")!,
        UIImage(named:"villan5.png")!
    ]
    
    func updatethrow(){
        targetSling.image = UIImage(named: "launch")
    }
    func changethrow(){
        targetSling.image = UIImage(named: "throw")
    }
    func chargethrow(){
        targetSling.image = UIImage(named: "charge")
    }
    
    func updateShuriken(currentPosition: CGPoint){
        sideX = currentPosition.x
        sideY = currentPosition.y
    }
    
    func generateShuriken(){
        let shurikenImage = UIImageView(image:nil)
        shurikenImage.image = UIImage(named: "Shuriken")
        shurikenImage.frame = CGRect(x: A*0.08, y: B*0.47, width: A*0.10, height: B*0.17)
        self.view.addSubview(shurikenImage)
        
        let angleX = sideX - self.targetSling.bounds.midX
        let angleY = sideY - B*0.5
        
        shurikenImageArray.append(shurikenImage)
        dynamicB.addItem(shurikenImage)
        dynamicB.addLinearVelocity(CGPoint(x: angleX*5, y:angleY*5), for:shurikenImage)
        collusionB.addItem(shurikenImage)
        
        let vanish = DispatchTime.now() + 3
        DispatchQueue.main.asyncAfter(deadline: vanish){
            shurikenImage.removeFromSuperview()
        }
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        start()
        //Background Animation
        var imageArray: [UIImage]!
        imageArray = [UIImage(named: "frame0.gif")!,
        UIImage(named: "frame1.gif")!,
        UIImage(named: "frame2.gif")!,
        UIImage(named: "frame3.gif")!,
        UIImage(named: "frame4.gif")!,
        UIImage(named: "frame5.gif")!,
        UIImage(named: "frame6.gif")!,
        UIImage(named: "frame7.gif")!,
        UIImage(named: "frame8.gif")!,
        UIImage(named: "frame9.gif")!,
        UIImage(named: "frame10.gif")!,
        UIImage(named: "frame11.gif")!,
        UIImage(named: "frame12.gif")!,
        UIImage(named: "frame13.gif")!]
        
        background2Image.image = UIImage.animatedImage(with: imageArray, duration: 1)
        
        timer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(ViewController.counter), userInfo: nil, repeats: true)
        
        self.targetSling.center.x = self.A * 0.10
        self.targetSling.center.y = self.B * 0.50
               
        targetSling.myDelegate = self
               
        dynamicA = UIDynamicAnimator(referenceView: self.view)
        dynamicB = UIDynamicItemBehavior(items: shurikenImageArray)
        dynamicA.addBehavior(dynamicB)
        dynamicA.addBehavior(ninjaCollusion)
               
        collusionB = UICollisionBehavior(items: [])
               
               
        collusionB = UICollisionBehavior(items: shurikenImageArray)
        //collisionBehavior.translatesReferenceBoundsIntoBoundary = true
               
        collusionB.addBoundary(withIdentifier: "LEFTScreen" as NSCopying, from: CGPoint(x: self.A*0.0, y: self.B*0.0), to: CGPoint(x: self.A*0.0, y: self.B*1.0))
               
        collusionB.addBoundary(withIdentifier: "TOPScreen" as NSCopying, from: CGPoint(x: self.A*0.0, y: self.B*0.0), to: CGPoint(x: self.A*1.0, y: self.B*0.0))
              
        collusionB.addBoundary(withIdentifier: "BOTTOMScreen" as NSCopying, from: CGPoint(x: self.A*0.0, y: self.B*1.0), to: CGPoint(x: self.A*1.0, y: self.B*1.0))
               
        dynamicA.addBehavior(collusionB)
}
    override func didReceiveMemoryWarning() {
                    super.didReceiveMemoryWarning()
     }
    
    func createVillanImage(){
        let enemy = 5
        let villanSize = Int(self.B)/enemy-2
        
        for index in 0...1000{
            let when = DispatchTime.now() + (Double(index)/2)
            DispatchQueue.main.asyncAfter(deadline: when) {
                while true {
                    let randomHeight = Int(self.B)/enemy * Int.random(in: 0...enemy)
                    let villanView = UIImageView(image: nil)
                    villanView.image = self.villanImageArray.randomElement()
                    villanView.frame = CGRect(x: self.A-CGFloat(villanSize), y:  CGFloat(randomHeight), width: CGFloat(villanSize),
                                   height: CGFloat(villanSize))
                    self.view.addSubview(villanView)
                    self.view.bringSubviewToFront(villanView)
                                   
                    for anyVillanView in self.villanViewArray {
                        if villanView.frame.intersects(anyVillanView.frame) {
                            villanView.removeFromSuperview()
                            continue
                        }
                    }
                                   
                    self.villanViewArray.append(villanView)
                    break;
                }
            }
                           
            }
        }
    
    func start(){
        self.createVillanImage()
        dynamicA = UIDynamicAnimator(referenceView: self.view)
        targetSling.frame = CGRect(x:A*0.02, y: B*0.4, width: A*0.2, height: B*0.2)
        targetSling.myDelegate = self
        ninjaCollusion = UICollisionBehavior(items: villanViewArray)
        self.ninjaCollusion.action = {
            for shurikenView in self.shurikenImageArray{
                for villanView in self.villanViewArray{
                    let index = self.villanViewArray.firstIndex(of: villanView)
                    if shurikenView.frame.intersects(villanView.frame)
                    {
                        villanView.removeFromSuperview()
                        self.villanViewArray.remove(at:index!)
                        self.score += 1
                        self.updateScore()
                    }
                }
            }
        }
        dynamicA.addBehavior(ninjaCollusion)
    }
    func updateScore(){
        points.text = "Score: " + "\(score)"
    }
    @objc func counter(){
        countdown -= 1
        timelimit.text = String(countdown)
        if (countdown == 0) {
            timer.invalidate()
            timelimitreached()
        }
    }
    
    func timelimitreached(){
        let main = UIStoryboard(name: "Main", bundle: nil)
        let replay = main.instantiateViewController(identifier: "replayVC")
        self.present(replay, animated: true, completion: nil)
    }
}
