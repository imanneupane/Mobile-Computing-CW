//
//  replayViewController.swift
//  ShooterGame
//
//  Created by il17aag on 11/01/2020.
//  Copyright © 2020 il17aag. All rights reserved.
//

import UIKit

class replayViewController: UIViewController {

    @IBOutlet weak var scorepoint: UILabel!
    @IBOutlet weak var loadBG: UIImageView!
    
    var scoreGot = ""
    @IBAction func restart(_ sender: Any) {
        let main = UIStoryboard(name: "Main", bundle: nil)
        let playPage = main.instantiateViewController(identifier: "mainVC")
        self.present(playPage, animated: true, completion: nil)
    }
    @IBAction func starter(_ sender: Any) {
        let main = UIStoryboard(name: "Main", bundle: nil)
        let menuPage = main.instantiateViewController(identifier: "homeVC")
        self.present(menuPage, animated: true, completion: nil)
    }
    @IBAction func secondStage(_ sender: Any) {
        /*var imageArray: [UIImage]!
        imageArray = [UIImage(named: "load2.gif")!,
        UIImage(named: "load3.gif")!,
        UIImage(named: "load4.gif")!,
        UIImage(named: "load5.gif")!,
        UIImage(named: "load6.gif")!,
        UIImage(named: "load7.gif")!,
        UIImage(named: "load8.gif")!,
        UIImage(named: "load9.gif")!,
        UIImage(named: "load10.gif")!,
        UIImage(named: "load11.gif")!,
        UIImage(named: "load12.gif")!,
        UIImage(named: "load13.gif")!,
        UIImage(named: "load14.gif")!,
        UIImage(named: "load15.gif")!,
        UIImage(named: "load16.gif")!,
        UIImage(named: "load17.gif")!,
        UIImage(named: "load18.gif")!,
        UIImage(named: "load19.gif")!,
        UIImage(named: "load20.gif")!,
        UIImage(named: "load21.gif")!,
        UIImage(named: "load22.gif")!,
        UIImage(named: "load23.gif")!,
        UIImage(named: "load24.gif")!,
        UIImage(named: "load25.gif")!,
        UIImage(named: "load26.gif")!,
        UIImage(named: "load27.gif")!,
        UIImage(named: "load28.gif")!,
        UIImage(named: "load29.gif")!,
        UIImage(named: "load30.gif")!,
        UIImage(named: "load31.gif")!]
        */
        //loadBG.image = UIImage.animatedImage(with: imageArray, duration: 2, Repeated: 1)
        
        let main = UIStoryboard(name: "Main", bundle: nil)
        let nextpage = main.instantiateViewController(identifier: "secondStage")
        self.present(nextpage, animated: true, completion: nil)
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        scorepoint.text = scoreGot
        let imageNames = ["load1.gif", "load2.gif","load3.gif", "load4.gif","load5.gif", "load6.gif","load7.gif", "load8.gif","load9.gif", "load10.gif","load11.gif", "load12.gif","load13.gif", "load14.gif","load15.gif", "load16.gif","load17.gif", "load18.gif","load19.gif", "load20.gif","load21.gif", "load22.gif","load23.gif", "load24.gif","load25.gif", "load26.gif","load27.gif", "load28.gif","load29.gif", "load30.gif","load31.gif"]
        var images = [UIImage]()
        for i in 0..<imageNames.count{
            images.append(UIImage(named: imageNames[i])!)
        }
        loadBG.animationImages = images
        loadBG.animationDuration = 2.0
        //loadBG.animationRepeatCount = 1
        loadBG.startAnimating()
        
    }

}
